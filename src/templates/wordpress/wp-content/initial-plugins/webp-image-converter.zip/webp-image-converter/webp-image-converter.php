<?php
/*
Plugin Name: WEBP Image Converter
Description: Automatically converts and compresses downloaded images into WEBP format.
Version: 1.0
Author: Alexandru Tostogan
*/

use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

require 'vendor/autoload.php';

add_filter('wp_handle_upload', 'convert_to_webp');

function convert_to_webp($file) {
	try {
		if ($file['type'] === 'image/jpeg' || $file['type'] === 'image/png') {
			$imagePath = $file['file'];
			$webpPath = preg_replace('/\.(jpg|jpeg|png)$/i', '.webp', $imagePath);

			$manager = new ImageManager(new Driver());
			$image = $manager->read($imagePath);
			$encoded = $image->toWebp(80);
			$encoded->save($webpPath);

			$file['guid'] = $webpPath;
			$file['file'] = $webpPath;
			$file['type'] = 'image/webp';
			$file['name'] = basename($webpPath);
		}
	} catch (Exception $e) {
		error_log("Ошибка при обработке файла: " . $e->getMessage(), 3, );
	}

	return $file;
}

add_action('add_attachment', 'set_image_alt_based_on_filename');

function set_image_alt_based_on_filename($post_ID): void {
	if (wp_attachment_is_image($post_ID)) {
		$file = get_attached_file($post_ID);
		$file_info = pathinfo($file);
		$alt = sanitize_text_field($file_info['filename']);
		update_post_meta($post_ID, '_wp_attachment_image_alt', $alt);
	}
}